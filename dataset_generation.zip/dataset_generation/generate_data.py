import argparse
import random
import networkx as nx
import numpy as np
import os
import time
from tqdm import tqdm

### ARGUMENTS ###
parser = argparse.ArgumentParser()
parser.add_argument("data")
parser.add_argument("p_rel", type=float)
parser.add_argument("p_new", type=float)
parser.add_argument("patience", type=int)
parser.add_argument("num_cand", type=int)
parser.add_argument("seed", type=int)
parser.add_argument("-s", "--save", action="store_true")
args = parser.parse_args()
### ARGUMENTS ###

### REPRODUCIBILITY ###
seed = int((args.p_rel + 1) * (args.p_new + 1) * args.patience * args.num_cand * args.seed)

random.seed(seed)
np.random.seed(seed)
os.environ['PYTHONHASHSEED'] = str(seed)
### REPRODUCIBILITY ###

### PARAMETERS ###
if args.p_new == 0.0:
	assert args.p_rel == 1.0
params = f"{args.data}--prel_{args.p_rel}--pnew_{args.p_new}--patience_{args.patience}--num_cand_{args.num_cand}--seed_{args.seed}"
### PARAMETERS ###

### HELPER FUNCTIONS ###
def remove_duplicate(x):
	return list(dict.fromkeys(x))

def gcc(triplet):
	G = nx.Graph()
	G.add_edges_from([h, t] for h, _, t in triplet)
	largest_cc = max(nx.connected_components(G), key=len)
	return set(largest_cc)

def extract_gcc(triplet):
	entities = gcc(triplet)
	res = []
	for h, r, t in triplet:
		if h in entities:
			res.append((h, r, t))
	return res

def construct_neighbor_dict(triplet):
	res = dict()
	for h, r, t in triplet:
		if h not in res:
			res[h] = set()
		res[h].add(t)
		if t not in res:
			res[t] = set()
		res[t].add(h)
	return res

def sample_neighbor(e, neighbor_dict, filter_entities, thr=50):
	neighbor = sorted(neighbor_dict[e] - filter_entities)
	if len(neighbor) > thr:
		neighbor = random.sample(neighbor, thr)
	return set(neighbor)

def check_gcc(triplet):
	entities = gcc(triplet)

	is_gcc = True
	for h, r, t in triplet:
		if h not in entities:
			is_gcc = False

	assert is_gcc

def check_intersection(list1, list2):
	assert len(set(list1).intersection(set(list2))) == 0

def check_transductive(task, triplet):
	set_ent = set([h for h, _, _ in triplet] + [t for _, _, t in triplet])
	for h, r, t in task:
		assert h in set_ent
		assert t in set_ent
### HELPER FUNCTIONS ###

start = time.time()

### READ TRIPLETS ###
with open(f"./raw/{args.data}.txt", 'r') as f:
	triplet_all = [tuple(line.strip().split()) for line in f.readlines()]
triplet_all = remove_duplicate(triplet_all)

print("Total number of triplets:", len(triplet_all))
### READ TRIPLETS ###

### EXTRACT GCC ###
triplet = extract_gcc(triplet_all)
entity = remove_duplicate([h for h, _, _ in triplet] + [t for _, _, t in triplet])
relation = remove_duplicate([r for _, r, _ in triplet])

print("Number of triplets in GCC:", len(triplet))
print("Number of entities:", len(entity))
print("Number of relations:", len(relation))
### EXTRACT GCC ###

### SPLIT RELATIONS ###
if args.p_new == 0.0: # Transductive
	relation_train = set(relation)
	relation_inference = set(relation)
elif args.p_new == 1.0: # Inductive
	random.shuffle(relation)
	relation_train = set(relation[:int(len(relation) * args.p_rel)])
	relation_inference = set(relation[int(len(relation) * args.p_rel):])
else: # Semi-Inductive
	random.shuffle(relation)
	relation_train = set(relation[:int(len(relation) * args.p_rel)])
	relation_inference = set(relation)
### SPLIT RELATIONS ###

### GENERATE TRAIN BASE ###
base_train = []
for h, r, t in triplet:
	if r in relation_train:
		base_train.append((h, r, t))
base_train = extract_gcc(base_train)

neighbor_train = construct_neighbor_dict(base_train)

base_entities_train = remove_duplicate([h for h, _, _ in base_train] + [t for _, _, t in base_train])

degree_train = np.zeros(len(base_entities_train))
for idx, e in enumerate(base_entities_train):
	degree_train[idx] = len(neighbor_train[e])
degree_train = degree_train / np.sum(degree_train)

seed_entity_train = np.random.choice(base_entities_train, p=degree_train)
seed_train = set([seed_entity_train])
list_entities_train = sorted(seed_train)
set_entities_train = set(list_entities_train)

neighbors = sample_neighbor(seed_entity_train, neighbor_train, set())
list_entities_train += sorted(neighbors - set_entities_train)
set_entities_train = set(list_entities_train)
### GENERATE TRAIN BASE ###

### GENERATE INFERENCE BASE ###
base_inference = []
for h, r, t in triplet:
	if (r in relation_inference) and (h not in set_entities_train) and (t not in set_entities_train):
		base_inference.append((h, r, t))
base_inference = extract_gcc(base_inference)

neighbor_inference = construct_neighbor_dict(base_inference)

base_entities_inference = remove_duplicate([h for h, _, _ in base_inference] + [t for _, _, t in base_inference])

degree_inference = np.zeros(len(base_entities_inference))
for idx, e in enumerate(base_entities_inference):
	degree_inference[idx] = len(neighbor_inference[e])
degree_inference = degree_inference / np.sum(degree_inference)

seed_entity_inference = np.random.choice(base_entities_inference, p=degree_inference)
seed_inference = set([seed_entity_inference])
list_entities_inference = sorted(seed_inference)
set_entities_inference = set(list_entities_inference)

neighbors = sample_neighbor(seed_entity_inference, neighbor_inference, set_entities_train)
list_entities_inference += sorted(neighbors - set_entities_inference)
set_entities_inference = set(list_entities_inference)
### GENERATE INFERENCE BASE ###

### ITERATIVELY EXPAND TRAIN/INFERENCE KG ###
patience = 0
num_iter = 0
while True:
	num_train = len(set_entities_train)
	num_inference = len(set_entities_inference)

	# Select new seed in train
	for _ in range(100):
		seed_entity_train = random.choice(list_entities_train)
		if seed_entity_train not in seed_train:
			break
		else:
			seed_entity_train = None

	if seed_entity_train != None:
		seed_train.add(seed_entity_train)

		# Collect 1-hop neighbors
		neighbors = sample_neighbor(seed_entity_train, neighbor_train, set_entities_inference)

		# Update train KG
		list_entities_train += sorted(neighbors - set_entities_train)
		set_entities_train = set(list_entities_train)

	# Select new seed in inference
	for _ in range(100):
		seed_entity_inference = random.choice(list_entities_inference)
		if seed_entity_inference not in seed_inference:
			break
		else:
			seed_entity_inference = None

	if seed_entity_inference != None:
		seed_inference.add(seed_entity_inference)

		# Collect 1-hop neighbors
		neighbors = sample_neighbor(seed_entity_inference, neighbor_inference, set_entities_train)

		# Update inference KG
		list_entities_inference += sorted(neighbors - set_entities_inference)
		set_entities_inference = set(list_entities_inference)
	num_iter += 1
	# Terminate when not updated
	if (num_train == len(set_entities_train)) and (num_inference == len(set_entities_inference)):
		patience += 1
		if patience == args.patience:
			break
	else:
		patience = 0
### ITERATIVELY EXPAND TRAIN/INFERENCE KG ###
print(num_iter)
### SANITY CHECK ###
assert len(set_entities_train.intersection(set_entities_inference)) == 0
### SANITY CHECK ###

### EXTRACT INDUCED SUBGRAPH OF TRAIN ENTITIES ###
train = []
for h, r, t in triplet:
	if (h in set_entities_train) and (r in relation_train) and (t in set_entities_train):
		train.append((h, r, t))

entity_train = set([h for h, _, _ in train] + [t for _, _, t in train])
relation_train = set(r for _, r, _ in train)
### EXTRACT INDUCED SUBGRAPH OF TRAIN ENTITIES ###

### GENERATE TRAIN BACKGROUND KG ###
relation_count_train = dict()
for h, r, t in train:
	if r not in relation_count_train:
		relation_count_train[r] = 0
	relation_count_train[r] += 1

relation_bg_train = set()
for r in relation_count_train:
	if relation_count_train[r] < 50 or relation_count_train[r] > 500:
		relation_bg_train.add(r)

bg_train = []
for h, r, t in train:
	if r in relation_bg_train:
		bg_train.append((h, r, t))
bg_train = extract_gcc(bg_train)

entity_train = set([h for h, _, _ in bg_train] + [t for _, _, t in bg_train])
relation_train = set(r for _, r, _ in bg_train)
### GENERATE TRAIN BACKGROUND KG ###

### EXTRACT INDUCED SUBGRAPH OF INFERENCE ENTITIES ###
if args.p_new == 0.0: # Transductive
	relation_inference = relation_train.copy()
elif args.p_new == 1.0: # Inductive
	relation_inference = set(relation) - relation_train

inference = []
for h, r, t in triplet:
	if (h in set_entities_inference) and (r in relation_inference) and (t in set_entities_inference):
		inference.append((h, r, t))

entity_inference = set([h for h, _, _ in inference] + [t for _, _, t in inference])
relation_inference = set(r for _, r, _ in inference)
### EXTRACT INDUCED SUBGRAPH OF INFERENCE ENTITIES ###

### GENERATE INFERENCE BACKGROUND KG ###
relation_count_inference = dict()
for h, r, t in inference:
	if r not in relation_count_inference:
		relation_count_inference[r] = 0
	relation_count_inference[r] += 1

relation_bg_inference = set()
for r in relation_count_inference:
	if relation_count_inference[r] < 50 or relation_count_inference[r] > 500:
		relation_bg_inference.add(r)

bg_inference = []
for h, r, t in inference:
	if r in relation_bg_inference:
		bg_inference.append((h, r, t))
bg_inference = extract_gcc(bg_inference)

entity_inference = set([h for h, _, _ in bg_inference] + [t for _, _, t in bg_inference])
relation_inference = set(r for _, r, _ in bg_inference)
### GENERATE INFERENCE BACKGROUND KG ###

### LOAD CANDIDATES ###
candidates = dict()
with open(f"./candidates/{args.data}.txt", 'r') as f:
	for line in f.readlines():
		r, t = line.strip().split()
		if r not in candidates:
			candidates[r] = set()
		candidates[r].add(t)

candidates_train, candidates_inference = dict(), dict()
for r in candidates:
	candidates_train[r] = len(candidates[r].intersection(entity_train))
	candidates_inference[r] = len(candidates[r].intersection(entity_inference))
### LOAD CANDIDATES ###

### GENERATE FEW-SHOT CANDIDATES ###
rel_cand_train, rel_cand_inference = dict(), dict()
for h, r, t in triplet:
	if (r in relation_train) or (r in relation_inference):
		continue

	if (h in entity_train) and (t in entity_train) and (candidates_train[r] > args.num_cand):
		if r not in rel_cand_train:
			rel_cand_train[r] = []
		rel_cand_train[r].append((h, r, t))

	if (h in entity_inference) and (t in entity_inference) and (candidates_inference[r] > args.num_cand):
		if r not in rel_cand_inference:
			rel_cand_inference[r] = []
		rel_cand_inference[r].append((h, r, t))
### GENERATE FEW-SHOT CANDIDATES ###

### CREATE TASKS ###
task_train, task_inference, task_undecided = [], [], []
for r in relation:
	if (r in rel_cand_train) and (len(rel_cand_train[r]) >= 50) and (len(rel_cand_train[r]) <= 500): # Satisfies train task
		if (r in rel_cand_inference) and (len(rel_cand_inference[r]) >= 50) and (len(rel_cand_inference[r]) <= 500): # Satisfies inference task
			task_undecided.append(r)
		else:
			task_train.append(r)
	else:
		if (r in rel_cand_inference) and (len(rel_cand_inference[r]) >= 50) and (len(rel_cand_inference[r]) <= 500): # Satisfies inference task
			task_inference.append(r)

print(f"task_train: {len(task_train)}, task_inference: {len(task_inference)}, task_undecided: {len(task_undecided)}")
### CREATE TASKS ###

### SPLIT TASKS ###
random.shuffle(task_inference)
task_valid = task_inference[:int(len(task_inference) / 3)]
task_test = task_inference[int(len(task_inference) / 3):]

random.shuffle(task_undecided)

for r in task_undecided:
	a_train = len(task_train) / 0.7
	a_valid = len(task_valid) / 0.1
	a_test = len(task_test) / 0.2

	if len(task_valid) < 5:
		task_valid.append(r)
	elif len(task_test) < 10:
		task_test.append(r)
	elif min([a_train, a_valid, a_test]) == a_train:
		task_train.append(r)
	elif min([a_train, a_valid, a_test]) == a_valid:
		task_valid.append(r)
	else:
		task_test.append(r)

tasks_train, tasks_valid, tasks_test = dict(), dict(), dict()
for r in task_train:
	tasks_train[r] = rel_cand_train[r]
for r in task_valid:
	tasks_valid[r] = rel_cand_inference[r]
for r in task_test:
	tasks_test[r] = rel_cand_inference[r]
### SPLIT TASKS ###

### SANITY CHECK ###
check_intersection(entity_train, entity_inference)
check_intersection(bg_train, bg_inference)
check_intersection(relation_train, task_train)
check_intersection(relation_train, task_valid)
check_intersection(relation_train, task_test)
check_intersection(relation_inference, task_train)
check_intersection(relation_inference, task_valid)
check_intersection(relation_inference, task_test)

check_gcc(bg_train)
check_gcc(bg_inference)

for r in tasks_train:
	check_transductive(tasks_train[r], bg_train)
for r in tasks_valid:
	check_transductive(tasks_valid[r], bg_inference)
for r in tasks_test:
	check_transductive(tasks_test[r], bg_inference)
### SANITY CHECK ###

### STATISTICS ###
print("# Entities in BG-Train:", len(entity_train))
print("# Relations in BG-Train:", len(relation_train))
print("# Triplets in BG-Train:", len(bg_train))
print()
print("# Entities in BG-Inference:", len(entity_inference))
print("# Relations in BG-Inference:", len(relation_inference))
print("# Known Relations in BG-Inference:", len(set(relation_inference).intersection(set(relation_train))))
print("# New Relations in BG-Inference:", len(set(relation_inference) - set(relation_train)))
print("# Triplets in BG-Inference:", len(bg_inference))
print()
print("# Tasks in Meta-Training:", len(tasks_train))
print("# Tasks in Meta-Validation:", len(tasks_valid))
print("# Tasks in Meta-Testing:", len(tasks_test))
print()
tri_known, tri_new = 0, 0
for h, r, t in bg_inference:
	if r in relation_train:
		tri_known += 1
	else:
		tri_new += 1
print(f"Ratio of New Relations in BG-Inference: {tri_new / len(bg_inference):.3f}")
### STATISTICS ###

### SAVE TO FILE ###
if args.save:
	os.makedirs(f"./result/{params}", exist_ok=True)
	with open(f"./result/{params}/bg-train.txt", "w") as f:
		for h, r, t in bg_train:
			f.write(f"{h}\t{r}\t{t}\n")

	with open(f"./result/{params}/bg-inference.txt", "w") as f:
		for h, r, t in bg_inference:
			f.write(f"{h}\t{r}\t{t}\n")

	with open(f"./result/{params}/task-train.txt", "w") as f:
		for r in sorted(tasks_train.keys()):
			random.shuffle(tasks_train[r])
			for h, r, t in tasks_train[r]:
				f.write(f"{h}\t{r}\t{t}\n")

	with open(f"./result/{params}/task-valid.txt", "w") as f:
		for r in sorted(tasks_valid.keys()):
			random.shuffle(tasks_valid[r])
			for h, r, t in tasks_valid[r]:
				f.write(f"{h}\t{r}\t{t}\n")
				
	with open(f"./result/{params}/task-test.txt", "w") as f:
		for r in sorted(tasks_test.keys()):
			random.shuffle(tasks_test[r])
			for h, r, t in tasks_test[r]:
				f.write(f"{h}\t{r}\t{t}\n")
### SAVE TO FILE ###

print(f"Total time elapsed: {time.time() - start:.3f} s")